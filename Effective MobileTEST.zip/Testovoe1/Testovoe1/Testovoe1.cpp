﻿#include <iostream>
#include <fstream>
#include <vector>
#include <windows.h>

class BMPReader {
 private:
    BITMAPFILEHEADER fileHeader;
    BITMAPINFOHEADER infoHeader;
    std::vector<unsigned char> pixelData;
    std::ifstream file;

public:
    BMPReader() = default;
    ~BMPReader() {
        closeBMP();
    }

    bool openBMP(const std::string& fileName) {
        file.open(fileName, std::ios::binary);
        if (!file) {
            std::cerr << "Не удалось открыть файл." << std::endl;
            return false;
        }

        file.read(reinterpret_cast<char*>(&fileHeader), sizeof(BITMAPFILEHEADER));
        file.read(reinterpret_cast<char*>(&infoHeader), sizeof(BITMAPINFOHEADER));

        if (infoHeader.biBitCount != 24 && infoHeader.biBitCount != 32) {
            std::cerr << "Поддерживаются только 24-битные и 32-битные BMP файлы." << std::endl;
            return false;
        }

        int paddingSize = (4 - (infoHeader.biWidth * (infoHeader.biBitCount / 8) % 4)) % 4;
        int rowSize = infoHeader.biWidth * (infoHeader.biBitCount / 8) + paddingSize;
        pixelData.resize(rowSize * std::abs(infoHeader.biHeight));

        file.seekg(fileHeader.bfOffBits, std::ios::beg);
        file.read(reinterpret_cast<char*>(pixelData.data()), pixelData.size());

        return true;
    }

    void displayBMP() {
        for (int y = std::abs(infoHeader.biHeight) - 1; y >= 0; --y) {
            for (int x = 0; x < infoHeader.biWidth; ++x) {
                int index = y * infoHeader.biWidth * (infoHeader.biBitCount / 8) + x * (infoHeader.biBitCount / 8);
                unsigned char b = pixelData[index];
                unsigned char g = pixelData[index + 1];
                unsigned char r = pixelData[index + 2];

                if (r == 0 && g == 0 && b == 0) {
                    std::cout << "#";
                }
                else if (r == 255 && g == 255 && b == 255) {
                    std::cout << " ";
                }
                else {
                    std::cout << ".";  // Для пикселей, не соответствующих чёрному или белому
                }
            }
            std::cout << std::endl;
        }
    }

    void closeBMP() {
        if (file.is_open()) {
            file.close();
        }
        pixelData.clear();
    }
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Использование: " << argv[0] << " <путь_к_файлу.bmp>" << std::endl;
        return 1;
    }

    BMPReader reader;
    if (!reader.openBMP(argv[1])) {
        return 1;
    }

    reader.displayBMP();

    return 0;
}